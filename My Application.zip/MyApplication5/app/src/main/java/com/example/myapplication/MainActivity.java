package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private String[] nama_bunga;
    private TypedArray photo;
    private String[] deskripsi;
    private String[] Kingdom;
    private String[] divisi;
    private String[] kelas;
    private String[] genus;

    private Adapter adapter;
    private ArrayList<Bunga> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prepare();
        list = addItems();

        Log.d(MainActivity.class.getSimpleName(), String.valueOf(list));

        adapter = new Adapter(this, list);
        ListView listView = findViewById(R.id.lv_list);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(MainActivity.this, DetailActivity.class);
                intent.putExtra(DetailActivity.EXTRA_PERSON, (Parcelable) list.get(position));
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.about) {
            Intent intent = new Intent(this, AboutActivity.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    private ArrayList<Bunga> addItems() {
        ArrayList<Bunga> item = new ArrayList<>();
        for (int i = 0; i < nama_bunga.length; i++) {
            Bunga bunga = new Bunga();
            bunga.setNama_bunga(nama_bunga[i]);
            bunga.setPhoto(photo.getResourceId(i, -1));
            bunga.setDeskripsi(deskripsi[i]);
            bunga.setKingdom(Kingdom[i]);
            bunga.setDivisi(divisi[i]);
            bunga.setKelas(kelas[i]);
            bunga.setGenus(genus[i]);
            item.add(bunga);

        }
        return item;
    }

    private void prepare() {
        nama_bunga = getResources().getStringArray(R.array.nama_bunga);
        photo = getResources().obtainTypedArray(R.array.photo);
        deskripsi = getResources().getStringArray(R.array.deskripsi);
        Kingdom = getResources().getStringArray(R.array.kingdom);
        divisi = getResources().getStringArray(R.array.divisi);
        kelas = getResources().getStringArray(R.array.kelas);
        genus = getResources().getStringArray(R.array.genus);
    }
}
