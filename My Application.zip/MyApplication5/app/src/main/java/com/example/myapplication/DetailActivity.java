package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class DetailActivity extends AppCompatActivity {
    public static final String EXTRA_PERSON = "extra_person";

    TextView tvnama_bunga;
    TextView tvdeskripsi;
    TextView tvkingdom;
    TextView tvdivisi;
    TextView tvkelas;
    TextView tvgenus;
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        Bunga bunga = getIntent().getParcelableExtra(EXTRA_PERSON);

        imageView = findViewById(R.id.iv_foto);
        Picasso.get().load(bunga.getPhoto()).into(imageView);

        tvnama_bunga = findViewById(R.id.tv_nama_bunga);
        tvnama_bunga.setText(bunga.getNama_bunga());

        tvdeskripsi = findViewById(R.id.tv_deskripsi);
        tvdeskripsi.setText(bunga.getDeskripsi());

        tvkingdom = findViewById(R.id.tv_kingdom);
        tvkingdom.setText(bunga.getKingdom());

        tvdivisi = findViewById(R.id.tv_divisi);
        tvdivisi.setText(bunga.getDivisi());

        tvkelas = findViewById(R.id.tv_kelas);
        tvkelas.setText(bunga.getKelas());

        tvgenus = findViewById(R.id.tv_genus);
        tvgenus.setText(bunga.getGenus());

    }
}