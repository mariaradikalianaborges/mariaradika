package com.example.myapplication;

import android.os.Parcel;
import android.os.Parcelable;

public class Bunga implements Parcelable {

    private Integer photo;
    private String nama_bunga;
    private String deskripsi;
    private String Kingdom;
    private String divisi;
    private String kelas;
    private String genus;

    public Bunga(){}

    protected Bunga(Parcel in) {
        if (in.readByte() == 0) {
            photo = null;
        } else {
            photo = in.readInt();
        }
        nama_bunga = in.readString();
        deskripsi = in.readString();
        Kingdom = in.readString();
        divisi = in.readString();
        kelas = in.readString();
        genus = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        if (photo == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeInt(photo);
        }
        dest.writeString(nama_bunga);
        dest.writeString(deskripsi);
        dest.writeString(Kingdom);
        dest.writeString(divisi);
        dest.writeString(kelas);
        dest.writeString(genus);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Bunga> CREATOR = new Creator<Bunga>() {
        @Override
        public Bunga createFromParcel(Parcel in) {
            return new Bunga(in);
        }

        @Override
        public Bunga[] newArray(int size) {
            return new Bunga[size];
        }
    };

    public Integer getPhoto() {
        return photo;
    }

    public void setPhoto(Integer photo) {
        this.photo = photo;
    }

    public String getNama_bunga() {
        return nama_bunga;
    }

    public void setNama_bunga(String nama_bunga) {
        this.nama_bunga = nama_bunga;
    }

    public String getDeskripsi() {
        return deskripsi;
    }

    public void setDeskripsi(String deskripsi) {
        this.deskripsi = deskripsi;
    }

    public String getKingdom() {
        return Kingdom;
    }

    public void setKingdom(String kingdom) {
        Kingdom = kingdom;
    }

    public String getDivisi() {
        return divisi;
    }

    public void setDivisi(String divisi) {
        this.divisi = divisi;
    }

    public String getKelas() {
        return kelas;
    }

    public void setKelas(String kelas) {
        this.kelas = kelas;
    }

    public String getGenus() {
        return genus;
    }

    public void setGenus(String genus) {
        this.genus = genus;
    }
}
